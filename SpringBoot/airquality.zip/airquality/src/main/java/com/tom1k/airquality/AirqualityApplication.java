package com.tom1k.airquality;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirqualityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirqualityApplication.class, args);
	}

}

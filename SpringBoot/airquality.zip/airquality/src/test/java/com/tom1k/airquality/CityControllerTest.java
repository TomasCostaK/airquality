package com.tom1k.airquality;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CityControllerTest {

    @Test
    void save() {
    }

    @Test
    void get() {
    }

    @Test
    void testGet() {
    }

    @Test
    void delete() {
    }

    @Test
    void update() {
    }
}